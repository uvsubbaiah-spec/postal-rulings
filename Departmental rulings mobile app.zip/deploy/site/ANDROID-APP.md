# Postal Rulings — Android app (APK)

## 1. Upload to the repo root (postal-rulings)
- index.html
- manifest.webmanifest
- sw.js
- icons/ (icon-192.png, icon-512.png, icon-maskable-512.png, apple-touch-icon.png)

Wait a minute for GitHub Pages, then open https://uvsubbaiah-spec.github.io/postal-rulings/ once.

## 2. Build the APK
1. Go to https://www.pwabuilder.com and enter https://uvsubbaiah-spec.github.io/postal-rulings/
2. Package for stores → Android → Generate Package → Options:
   - Package ID: io.github.uvsubbaiah_spec.postalrulings
   - App name: Postal Rulings · Short name: Postal Rulings
   - Signing key: Create new (keep the downloaded zip safe; every future update must use the same key)
3. Download. The zip contains an .apk (install directly), an .aab (Play Store only), assetlinks.json and signing.keystore.

## 3. Publish the download link
1. GitHub repo → Releases → Draft a new release → tag v1.0.0.
2. Attach the .apk renamed to exactly: postal-rulings.apk
3. Publish. The blog's "Get App" button and the app's Android banner point to:
   https://github.com/uvsubbaiah-spec/postal-rulings/releases/latest/download/postal-rulings.apk
   For updates, publish a new release with the same file name; the link stays the same.

## 4. Hide the address bar inside the app (optional)
Android checks https://uvsubbaiah-spec.github.io/.well-known/assetlinks.json (the root of the github.io domain, not /postal-rulings/).
1. Create a repo named exactly uvsubbaiah-spec.github.io with Pages enabled.
2. Put the assetlinks.json from the PWABuilder zip at .well-known/assetlinks.json in that repo, plus an empty .nojekyll file at its root.
Without this the app works but shows a thin address bar at the top.

## Installing on a phone
Open the Get App link on the phone → download → open the file → allow "Install unknown apps" for the browser when asked.
